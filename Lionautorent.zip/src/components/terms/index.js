export { default } from './terms.js';
