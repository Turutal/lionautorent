export { default } from './pagination.js';
