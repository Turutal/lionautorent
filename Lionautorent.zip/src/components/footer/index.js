export { default } from './footer.js';
